<template>
  <div id="app">
    <!--Navigation Bar -->
    <nav class="navbar">
      <div class="container nav-container">
        <!-- King Software Brand Logo -->
        <div class="navbar-brand">
          <n-avatar src="/crown.svg" class="logo-avatar"/>
          <a href="#">My Personal Website</a>
        </div>
        <n-space align="flex-end">
        </n-space>
        <!-- Navigation bar menu -->
        <div class="nav-links">
          <a class="nav-link" href="#home" @click.prevent="scrollToSection('home')">Home</a>
          <a class="nav-link" href="#projects" @click.prevent="scrollToSection('projects')">Projects</a>
          <a class="nav-link" href="#contact" @click.prevent="scrollToSection('contact')">Contact</a>
        </div>
      </div>
      
      
    </nav>

    <!-- Home Section -->
    <section id="home" ref="home" class="section">
      <div class="container content-container">
        <h1 class="section-title">Hello!</h1>
        <div v-if="showWelcome" class="welcome-card">
          <p>Welcome to my personal website! </p>
        </div>
        <p class="section-intro">This is my simple and modern web applicaton in Vue!</p>
        <button @click="toggleWelcome" class="btn">
          {{ showWelcome ? 'Hide' : 'Show' }} Welcome Message
        </button>
        
        <!-- Counter -->
        <div class="counter-container">
          <p class="counter-text">Visitor Interactions: <span class="counter-value">{{ visitorCount }}</span></p>
          <button @click="incrementCounter" class="btn counter-btn">Click to Increment</button>
        </div>
        
        <!-- v-show requirement for Assignment 3 rubric-->
        <div class="message-toggle-container">
          <button @click="toggleMessage" class="btn message-toggle-btn">
            {{ showMessage ? 'Hide' : 'Show' }} Portfolio Details
          </button>
          <div v-show="showMessage" class="portfolio-details">
            <h3>About My Website</h3>
            <p>This web application showcases my skills in Vue.js development, responsive design, and interactive web applications. I focus on creating clean, user-friendly interfaces with modern technologies.</p>
            <p>Feel free to explore my projects and get in touch if you'd like to collaborate!</p>
          </div>
          <div class="learning-resources">
  <h3>Learning Resources</h3>
  <p>If you want to learn how to use Vue here is a good video I used to help me make this website!</p>
  <div class="video-container">
    <iframe 
      width="100%" 
      height="400" 
      src="https://www.youtube.com/embed/1GNsWa_EZdw" 
      title="Vue.js Tutorial: Beginner to Front-End Developer" 
      frameborder="0" 
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
      referrerpolicy="strict-origin-when-cross-origin" 
      allowfullscreen>
    </iframe>
  </div>
</div>
        </div>
      </div>
    </section>

    <!-- Projects Display -->
    <section id="projects" ref="projects" class="section projects-section">
      <div class="container content-container">
        <h2 class="section-title">Projects</h2>
    
        <div class="project-stats">
          <h3>Project Statistics</h3>
          <p>{{ projectSummary }}</p>
        </div>
        <div class="projects-grid">
          <div v-for="(project, index) in projects" :key="index" class="project-card">
            <h3 class="project-title">{{ project.title }}</h3>
            <p class="project-description">{{ project.description }}</p>
            <div class="project-tech">
              <span class="tech-label">Technologies:</span>
              <span class="tech-items">{{ project.technologies }}</span>
            </div>
            <!-- METAR widget project -->
            <div v-if="project.title === 'METAR App Aviation Weather'" class="metar-widget" ref="metarWidget">
            </div>


          </div>
        </div>
      </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" ref="contact" class="section contact-section">
      <div class="container content-container">
        <h2 class="section-title">Contact Me</h2>
        <form @submit.prevent="submitForm" class="contact-form">
          <div class="form-group">
            <label for="name">Name</label>
            <input type="text" id="name" v-model="contactForm.name" required>
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" v-model="contactForm.email" required>
          </div>
          <div class="form-group">
            <label for="message">Message</label>
            <textarea id="message" v-model="contactForm.message" rows="5" required></textarea>
          </div>
          <button type="submit" class="btn submit-btn">Send Message</button>
        </form>
        <div v-if="formSubmitted" class="success-message">
          Thank you for your message, {{ contactForm.name }}! I'll get back to you soon.
        </div>
      </div>
    </section>

    <!--  Footer -->
    <footer class="footer">
      <div class="container">
        <p>&copy; {{ new Date().getFullYear() }} King Software LLC.</p>
      </div>
    </footer>
  </div>
</template>

<script>
import { NConfigProvider, NSpace, NAvatar } from 'naive-ui'
import { defineComponent, ref, computed, watch } from 'vue'

export default {
  name: 'App',
  components: {
    NConfigProvider,
    NSpace,
    NAvatar
  },
  
  setup() {
    // Reactive state with ref()
    const visitorCount = ref(0);
    const showMessage = ref(false);
    const contactForm = ref({
      name: "",
      email: "",
      message: ""
    });
    
    // Projects data
    const projects = ref([
      {
        title: "To-Do List App",
        description: "A simple to-do list application with task management features.",
        technologies: "Vue.js, LocalStorage"
      },
      {
        title: "METAR App Aviation Weather",
        description: "Real-time weather forecasting application using external API integration.",
        technologies: "Vue.js, API, CSS Animations"
      },
    ]);
    
    //Project summary 
    const projectSummary = computed(() => {
      const totalProjects = projects.value.length;
      const techCount = new Set(projects.value.flatMap(p => 
        p.technologies.split(',').map(t => t.trim())
      )).size;
      
      return `Currently showcasing ${totalProjects} projects using ${techCount} different technologies. Average project description length: ${Math.round(projects.value.reduce((acc, curr) => acc + curr.description.length, 0) / totalProjects)} characters.`;
    });
    
    // Watch function for counter
    watch(() => contactForm.value, (newValue, oldValue) => {
      console.log('Form updated:', {
        previous: oldValue,
        current: newValue,
        changes: Object.keys(newValue).filter(key => newValue[key] !== oldValue[key])
      });
    }, { deep: true });
    
    // Counter increment 
    const incrementCounter = () => {
      visitorCount.value++;
      console.log('Visitor count incremented to:', visitorCount.value);
    };
    
    //  Message visibility
    const toggleMessage = () => {
      showMessage.value = !showMessage.value;
    };
    
    return {
      visitorCount,
      incrementCounter,
      showMessage,
      toggleMessage,
      projects,
      projectSummary,
      contactForm
    };
  },
  
  data() {
    return {
      showWelcome: true,
      mobileMenuOpen: false,
      formSubmitted: false
    };
  },
  
  mounted() {
    // Add METAR widget after component is mounted
    this.$nextTick(() => {
      this.loadMetarWidget();
    });
  },
  
  updated() {
    // Reload widget when component updates (in case it's not loaded properly the first time)
    this.$nextTick(() => {
      if (this.$refs.metarWidget && !document.getElementById('metartaf-asw4B2pd')) {
        this.loadMetarWidget();
      }
    });
  },
  
  methods: {
    loadMetarWidget() {
      if (this.$refs.metarWidget) {
        // Create the widget link element
        const widgetLink = document.createElement('a');
        widgetLink.href = 'https://metar-taf.com/KATL';
        widgetLink.id = 'metartaf-asw4B2pd';
        widgetLink.style.fontSize = '18px';
        widgetLink.style.fontWeight = '500';
        widgetLink.style.color = '#000';
        widgetLink.style.width = '350px';
        widgetLink.style.height = '278px';
        widgetLink.style.display = 'block';
        widgetLink.style.margin = '20px auto 0';
        widgetLink.textContent = 'METAR Hartsfield/Jackson Atlanta International';
        
        // Create the script element
        const script = document.createElement('script');
        script.async = true;
        script.defer = true;
        script.crossOrigin = 'anonymous';
        script.src = 'https://metar-taf.com/embed-js/KATL?layout=landscape&visibility=mi&qnh=inHg&rh=rh&target=asw4B2pd';
        
        // Append them to the widget container
        if (this.$refs.metarWidget.firstChild) {
          this.$refs.metarWidget.innerHTML = '';
        }
        this.$refs.metarWidget.appendChild(widgetLink);
        this.$refs.metarWidget.appendChild(script);
      }
    },
    
    toggleWelcome() {
      this.showWelcome = !this.showWelcome;
    },
    
    toggleMenu() {
      this.mobileMenuOpen = !this.mobileMenuOpen;
    },
    
    submitForm() {
      console.log("Form submitted:", this.contactForm);
      this.formSubmitted = true;
      
      setTimeout(() => {
        this.contactForm = {
          name: "",
          email: "",
          message: ""
        };
        this.formSubmitted = false;
      }, 5000);
    },
    
    scrollToSection(sectionId) {
      this.$refs[sectionId].scrollIntoView({ behavior: 'smooth' });
    },
    
    scrollToSectionMobile(sectionId) {
      this.mobileMenuOpen = false;
      setTimeout(() => {
        this.$refs[sectionId].scrollIntoView({ behavior: 'smooth' });
      }, 300);
    }
  }
};
</script>

<style>

.logo {
  height: 30px; 
  margin-right: 15px; 
  vertical-align: middle; 
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

:root {
  --primary: #3a7bd5;
  --primary-light: #4a8fef;
  --dark: #2d3748;
  --gray: #718096;
  --light: #f7fafc;
  --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Inter', 'Segoe UI', sans-serif;
}

body {
  color: var(--dark);
  line-height: 1.7;
  background-color: var(--light);
}

.container {
  max-width: 1140px;
  margin: 0 auto;
  padding: 0 20px;
}


.navbar {
  background-color: rgb(222, 222, 222);
  box-shadow: var(--shadow);
  position: fixed;
  width: 100%;
  top: 0;
  left: 0;
  z-index: 1000;
}

.nav-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 0;
}

.navbar-brand {
  display: flex;
  align-items: center;
  gap: 10px; /* Adjust spacing between avatar and text */
  text-decoration: none;
  color: #000000;
  font-size: 1.5rem;
  font-weight: 700;
  font-family: 'Montserrat', sans-serif;
}

.logo-avatar {
  width: 30px; /* Adjust size as needed */
  height: 30px;
}

.nav-links {
  display: flex;
  gap: 30px;
}

.nav-link {
  color: var(--dark);
  text-decoration: none;
  font-weight: 500;
  transition: color 0.3s;
}

.nav-link:hover {
  color: var(--primary);
}

.menu-toggle {
  display: none;
  background: none;
  border: none;
  cursor: pointer;
  flex-direction: column;
  gap: 6px;
}

.menu-toggle span {
  display: block;
  width: 25px;
  height: 2px;
  background-color: var(--dark);
  transition: transform 0.3s;
}

.mobile-menu {
  display: none;
  flex-direction: column;
  background-color: white;
  padding: 20px;
  text-align: center;
  transform: translateY(-100%);
  transition: transform 0.3s ease;
  position: absolute;
  top: 100%;
  left: 0;
  width: 100%;
  box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
}

.mobile-menu.active {
  transform: translateY(0);
}

.mobile-link {
  color: var(--dark);
  text-decoration: none;
  font-weight: 500;
  padding: 12px 0;
  display: block;
  border-bottom: 1px solid #edf2f7;
}

.mobile-link:last-child {
  border-bottom: none;
}

.section {
  padding: 120px 0 80px;
  min-height: 100vh;
  display: flex;
  align-items: center;
}

.content-container {
  width: 100%;
}

.section-title {
  font-size: 2.5rem;
  font-weight: 700;
  color: var(--dark);
  position: relative;
  margin-bottom: 40px;
  padding-bottom: 15px;
  text-align: center;
}

.section-title::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 60px;
  height: 4px;
  background-color: var(--primary);
  border-radius: 2px;
}

.section-intro {
  font-size: 1.5rem;
  color: var(--gray);
  margin-bottom: 30px;
  text-align: center;
}

/* Welcome section */
.welcome-card {
  background-color: white;
  border-radius: 8px;
  padding: 25px;
  margin-bottom: 30px;
  box-shadow: var(--shadow);
  border-left: 5px solid var(--primary);
}


.counter-container {
  background-color: white;
  border-radius: 8px;
  padding: 25px;
  margin: 30px 0;
  box-shadow: var(--shadow);
  text-align: center;
}

.counter-text {
  font-size: 1.2rem;
  margin-bottom: 15px;
  color: var(--dark);
}

.counter-value {
  font-weight: 700;
  color: var(--primary);
  font-size: 1.5rem;
}

.counter-btn {
  margin-top: 15px;
  background-color: var(--primary);
}

/* Message toggle styles */
.message-toggle-container {
  margin: 30px 0;
}

.message-toggle-btn {
  margin-bottom: 20px;
}

.portfolio-details {
  background-color: white;
  border-radius: 8px;
  padding: 25px;
  box-shadow: var(--shadow);
  text-align: left;
  border-left: 5px solid var(--primary-light);
  margin-top: 20px;
}

.portfolio-details h3 {
  color: var(--dark);
  margin-bottom: 15px;
  font-size: 1.3rem;
}

.portfolio-details p {
  margin-bottom: 15px;
}

/* Project stats */
.project-stats {
  background-color: white;
  border-radius: 8px;
  padding: 25px;
  margin-bottom: 40px;
  box-shadow: var(--shadow);
  text-align: center;
}

.project-stats h3 {
  color: var(--dark);
  margin-bottom: 15px;
  font-size: 1.3rem;
}

.project-stats p {
  color: var(--gray);
  line-height: 1.6;
}

/* Button styling */
.btn {
  background-color: var(--primary);
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
  transition: background-color 0.3s;
  display: block;
  margin: 0 auto;
}

.btn:hover {
  background-color: var(--primary-light);
}

/* Projects section */
.projects-section {
  background-color: #f8fafc;
}

.projects-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 30px;
}

.project-card {
  background-color: white;
  border-radius: 8px;
  padding: 25px;
  box-shadow: var(--shadow);
  transition: transform 0.3s;
}

.project-card:hover {
  transform: translateY(-5px);
}

.project-title {
  color: var(--dark);
  margin-bottom: 15px;
  font-size: 1.3rem;
}

.project-description {
  color: var(--gray);
  margin-bottom: 20px;
}

.project-tech {
  display: flex;
  flex-direction: column;
  gap: 5px;
  margin-bottom: 15px;
}

.tech-label {
  font-weight: 600;
  color: var(--dark);
}

.tech-items {
  color: var(--primary);
  font-size: 0.9rem;
}

/* METAR Widget styling */
.metar-widget {
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px solid #e2e8f0;
}

/* Contact section */
.contact-section {
  background-color: white;
}

.contact-form {
  max-width: 600px;
  margin: 0 auto;
}

.form-group {
  margin-bottom: 25px;
}

label {
  display: block;
  font-weight: 500;
  margin-bottom: 8px;
  color: var(--dark);
}

input, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  transition: border 0.3s;
  font-size: 1rem;
}

input:focus, textarea:focus {
  outline: none;
  border-color: var(--primary);
}

.submit-btn {
  width: 100%;
  font-size: 1rem;
  margin-top: 10px;
}

.success-message {
  background-color: #c6f6d5;
  color: #276749;
  padding: 15px;
  border-radius: 6px;
  margin-top: 30px;
  text-align: center;
}

/* Video container for responsive embedding */
.learning-resources {
  background-color: white;
  border-radius: 8px;
  padding: 25px;
  margin: 30px 0;
  box-shadow: var(--shadow);
}

.learning-resources h3 {
  color: var(--dark);
  margin-bottom: 15px;
  font-size: 1.3rem;
}

.video-container {
  position: relative;
  padding-bottom: 56.25%; /* 16:9 aspect ratio */
  height: 0;
  overflow: hidden;
  max-width: 100%;
  margin-top: 20px;
}

.video-container iframe {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border-radius: 6px;
}

/* Footer */
.footer {
  background-color: var(--dark);
  color: white;
  padding: 30px 0;
  text-align: center;
}

/* Responsive design */
@media (max-width: 768px) {
  .nav-links {
    display: none;
  }
  
  .menu-toggle {
    display: flex;
  }
  
  .mobile-menu {
    display: flex;
  }
  
  .section {
    padding: 100px 0 60px;
  }
  
  .section-title {
    font-size: 2rem;
  }
  
  .section-intro {
    font-size: 1.2rem;
  }
  
  .projects-grid {
    grid-template-columns: 1fr;
  }
  
  .counter-container,
  .message-toggle-container,
  .portfolio-details,
  .project-stats {
    padding: 20px;
  }
}
</style>